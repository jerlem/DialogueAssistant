﻿using System;
using System.Threading;
using System.Windows.Forms;

namespace launcher
{
    internal static class Program
    {
        [STAThread]
        static void Main()
        {
            ApplicationConfiguration.Initialize();

            // Affiche le splash
            using (var splash = new SplashScreen())
            {
                splash.Show();
                splash.Refresh(); // Update -> Refresh est plus sûr

                // Simulation du chargement
                Thread.Sleep(3000);
            }

            // Lance la fenêtre principale
            Application.Run(new Main());
        }
    }
}