﻿using System.Diagnostics;

namespace launcher
{
    public partial class Main : Form
    {
        //private NotifyIcon trayIcon;
        //private ContextMenuStrip trayMenu;

        public Main()
        {
            InitializeComponent();
        }

        private void Main_Load(object sender, EventArgs e)
        {
            InitializeComponent();

            FormBorderStyle = FormBorderStyle.None;
            ShowInTaskbar = false;
            WindowState = FormWindowState.Minimized;
            Opacity = 0;

            //trayIcon = new NotifyIcon
            //{
            //    Text = "Process Launcher",
            //    Icon = new Icon(Path.Combine(Application.StartupPath, "icon.ico")),
            //    ContextMenuStrip = trayMenu,
            //    Visible = true
            //};

            //trayIcon.MouseClick += TrayIcon_MouseClick;

            LaunchProcessesAsync();
        }

        private async Task LaunchProcessesAsync()
        {
           
            // start bat file
            string batPath = Path.Combine(Application.StartupPath, "startserver.bat");
            if (File.Exists(batPath))
            {
                Process.Start(new ProcessStartInfo
                {
                    FileName = batPath,
                    UseShellExecute = true
                });
            }

            Application.Exit();
        }

        //private void TrayIcon_MouseClick(object sender, MouseEventArgs e)
        //{
        //    if (e.Button == MouseButtons.Left || e.Button == MouseButtons.Right)
        //    {
        //        // Fermer l’application au clic sur l’icône
        //        trayIcon.Visible = false;
        //        Application.Exit();
        //    }
        //}

        //protected override void OnFormClosing(FormClosingEventArgs e)
        //{
        //    trayIcon.Visible = false;
        //    base.OnFormClosing(e);
        //}
    }

}

